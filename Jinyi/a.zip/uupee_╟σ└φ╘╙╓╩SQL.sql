Update uupee_posts SET post_content = replace (post_content,'<div class="hide data"></div>','') Where post_content LIKE '%<div class="hide data"></div>%';
Update uupee_posts SET post_content = replace (post_content,'<p><!-- start article nav --></p>','') Where post_content LIKE '%<p><!-- start article nav --></p>%';
Update uupee_posts SET post_content = replace (post_content,'<div class="art-pagination"></div>','') Where post_content LIKE '%<div class="art-pagination"></div>%';

Update uupee_posts SET post_content = replace (post_content,'<!-- end article nav --><p>&nbsp;&nbsp;&nbsp; ','<p>') Where post_content LIKE '%<!-- end article nav --><p>&nbsp;&nbsp;&nbsp; %';



Update uupee_posts SET post_content = replace (post_content,'<div class="hint mt20">提示：支持键盘“← →”键翻页 阅读全文</div>','') Where post_content LIKE '%<div class="hint mt20">提示：支持键盘“← →”键翻页 阅读全文</div>%';

Update uupee_posts SET post_content = replace (post_content,'<!-- start 广告位 --><div class="ad mt20"></div>','') Where post_content LIKE '%<!-- start 广告位 --><div class="ad mt20"></div>%';
Update uupee_posts SET post_content = replace (post_content,'<!-- end 广告位 --><p><br /></p>','') Where post_content LIKE '%<!-- end 广告位 --><p><br /></p>%';


Update uupee_posts SET post_content = replace (post_content,'<img class="aligncenter size-full wp-image-7553" src="https://plus.wps.cn/blog/wp-content/uploads/2019/01/footer_ad1.png" alt="" width="752" height="275" />','') Where post_content LIKE '%<img class="aligncenter size-full wp-image-7553" src="https://plus.wps.cn/blog/wp-content/uploads/2019/01/footer_ad1.png" alt="" width="752" height="275" />%';
Update uupee_posts SET post_content = replace (post_content,'提示：支持键盘“← →”键翻页','') Where post_content LIKE '%提示：支持键盘“← →”键翻页%';
Update uupee_posts SET post_content = replace (post_content,'阅读全文','') Where post_content LIKE '%阅读全文%';


Update uupee_posts SET post_content = replace (post_content,'	','') Where post_content LIKE '%	%';
Update uupee_posts SET post_content = replace (post_content,'&nbsp;&nbsp;&nbsp;','') Where post_content LIKE '%&nbsp;&nbsp;&nbsp;%';

Update uupee_posts SET post_content = replace (post_content,'想了解更多精彩教程资讯，记得关注wmzhe.com。','') Where post_content LIKE '%想了解更多精彩教程资讯，记得关注wmzhe.com。%';

Update uupee_posts SET post_content = replace (post_content,'<p class="post-copyright">转载请保留原文链接：Linux运维日志 &raquo;','<p>') Where post_content LIKE '%<p class="post-copyright">转载请保留原文链接：Linux运维日志 &raquo;%';


Update uupee_posts SET post_content = replace (post_content,'<p>有运维或运维开发方面的需求，可以联系博主QQ 452336092或Email:admin#centos.bz(收费)</p>','') Where post_content LIKE '%<p>有运维或运维开发方面的需求，可以联系博主QQ 452336092或Email:admin#centos.bz(收费)</p>%';

Update uupee_posts SET post_content = replace (post_content,'<blockquote></blockquote>','') Where post_content LIKE '%<blockquote></blockquote>%';

Update uupee_posts SET post_content = replace (post_content,'<!--  -->','') Where post_content LIKE '%<!--  -->%';


Update uupee_posts SET post_content = replace (post_content,'<!--start广告位--><div class="admt20"></div><!--end广告位-->','') Where post_content LIKE '%<!--start广告位--><div class="admt20"></div><!--end广告位-->%';

Update uupee_posts SET post_content = replace (post_content,'<p><!--startarticlenav--><!--endarticlenav--','') Where post_content LIKE '%<p><!--startarticlenav--><!--endarticlenav--%';

Update uupee_posts SET post_content = replace (post_content,'<script type="text/javascript" language="javascript">
window.content_index_showTocToggle=true;function content_index_toggleToc(){var tts="显示";var tth="隐藏";if(window.content_index_showTocToggle){window.content_index_showTocToggle=false;document.getElementById("content-index-contents").style.display="none";document.getElementById("content-index-togglelink").innerHTML=tts}else{window.content_index_showTocToggle=true;document.getElementById("content-index-contents").style.display="block";document.getElementById("content-index-togglelink").innerHTML=tth}}
</script>','') Where post_content LIKE '%<script type="text/javascript" language="javascript">
window.content_index_showTocToggle=true;function content_index_toggleToc(){var tts="显示";var tth="隐藏";if(window.content_index_showTocToggle){window.content_index_showTocToggle=false;document.getElementById("content-index-contents").style.display="none";document.getElementById("content-index-togglelink").innerHTML=tts}else{window.content_index_showTocToggle=true;document.getElementById("content-index-contents").style.display="block";document.getElementById("content-index-togglelink").innerHTML=tth}}
</script>%';



Update uupee_posts SET post_content = replace (post_content,'<p><img class="size-full wp-image-7857 aligncenter" src="https://plus.wps.cn/blog/wp-content/uploads/2019/01/footer_ad1-5.png" alt="" width="752" height="275" /></p>','') Where post_content LIKE '%<p><img class="size-full wp-image-7857 aligncenter" src="https://plus.wps.cn/blog/wp-content/uploads/2019/01/footer_ad1-5.png" alt="" width="752" height="275" /></p>%';


Update uupee_posts SET post_title = replace (post_title,'','') Where post_title LIKE '%%';
