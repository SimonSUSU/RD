
var PageName = '促销活动';
var PageId = 'pa9cec0c4536047679ab405586da1856a'
var PageUrl = '促销活动.html'
document.title = '促销活动';

if (top.location != self.location)
{
	if (parent.HandleMainFrameChanged) {
		parent.HandleMainFrameChanged();
	}
}

if (window.OnLoad) OnLoad();
