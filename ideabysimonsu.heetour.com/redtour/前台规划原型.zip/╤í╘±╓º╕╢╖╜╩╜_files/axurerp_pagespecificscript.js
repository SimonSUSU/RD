
var PageName = '选择支付方式';
var PageId = 'p12e997839f0c4ea6befd544ab1d05613'
var PageUrl = '选择支付方式.html'
document.title = '选择支付方式';

if (top.location != self.location)
{
	if (parent.HandleMainFrameChanged) {
		parent.HandleMainFrameChanged();
	}
}

if (window.OnLoad) OnLoad();
